# [wrench](http://gochojr.github.io/blogsite/wrench)

Welcome to the [wrench](https://bitbucket.org/gochojr/wrench/) wiki!

## Contributions

This wiki guides you on how to contribute to [wrench](http://gochojr.github.io/wrench). You can contribute in the following ways:

- Use bower components and pak library to test and develop [wrench](http://gochojr.github.io/blogsite/wrench) 
- Inject your own magick to [wrench](http://gochojr.github.io/blogsite/wrench) using anything in the development directory
- Edit the [wrench](http://gochojr.github.io/blogsite/wrench) wiki

The wiki itself is actually a mercurial repository, which means if you want a copy of it you can clone it.

Go ahead and try:

```
$ hg clone https://gochojr@bitbucket.org/gochojr/wrench/wiki
```

## Bower components

You can get yourself a copy of wrench development directory from [wrench bucket repo](https://bitbucket.org/gochojr/wrench/) using [Mercurial](https://www.mercurial-scm.org/wiki/TortoiseHg) by cloning the wrench repo.

The Bower components include:

1. [Laurus.TaskBoss](https://github.com/thebeekeeper/Laurus.TaskBoss)
2. [bat by JofaHbx](https://github.com/JofaHbx/bat)
3. [bat2exe](https://github.com/islamadel/bat2exe)
4. [win32-bat2exe](https://github.com/juntalis/win32-bat2exe)



## Pak catalog

You can get yourself a copy of wrench development directory from [wrench bucket repo](https://bitbucket.org/gochojr/wrench/) using [Mercurial](https://www.mercurial-scm.org/wiki/TortoiseHg) by cloning the wrench repo.

The Pak catalog include:

1. [Batsh](https://github.com/BYVoid/Batsh) 

Batsh requires you to install [OPAM](http://opam.ocaml.org/doc/Install.html) or just build from [source](https://github.com/BYVoid/Batsh/releases)


## The only Rule is ?

Do your thing but importantly test it and save a copy of `test.cmd` or `test.bat` or `test.sh ` and push it to your **OWN** created branch with suitable heading.

