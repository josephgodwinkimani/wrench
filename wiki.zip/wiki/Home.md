# [wrench](http://gochojr.github.io/blogsite/wrench)

Welcome to the [wrench](https://bitbucket.org/gochojr/wrench/) wiki!

## Wiki features 

This wiki guides you on how to use [wrench](http://gochojr.github.io/wrench). Here you will learn the following:

- Download [wrench](http://gochojr.github.io/blogsite/wrench) 
- Install [wrench](http://gochojr.github.io/blogsite/wrench) 
- Use [wrench](http://gochojr.github.io/blogsite/wrench) 

The wiki itself is actually a mercurial repository, which means if you want a copy of it you can clone it.

Go ahead and try:

```
$ hg clone https://gochojr@bitbucket.org/gochojr/wrench/wiki
```

## Download

You can get yourself a copy of wrench as executable from [wrench bucket repo](https://bitbucket.org/gochojr/wrench/) using [Mercurial](https://www.mercurial-scm.org/wiki/TortoiseHg) by cloning the wrench repo.

## Alternative Download

If you want the easy way download wrench from here: [sourceforge/wrench](https://sourceforge.net/projects/wrench/) 

## Install

[wrench](http://gochojr.github.io/blogsite/wrench) does not need any installation! After [cloning wrench repo](https://bitbucket.org/gochojr/wrench) `cd` to where you cloned it and right click on executable written **wrench** with the wrench icon.

## First Use!

You are ready to dig down to the important bits! Run the following command:
```
wrench

```
Now you will see another wrench shell! :smile:

Next run the command `mancommand` to see all shell commands at your disposal! 

**Note:** This will list all `cmd` commands first and then the wrench commands next~ dont be a kvetcher keypress that `enter` till `z`. 

Shell Happy? :smile: Start contributing to [wrench project](https://bitbucket.org/gochojr/wrench) now!

